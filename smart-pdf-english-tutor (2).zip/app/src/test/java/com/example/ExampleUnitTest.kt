package com.example

import com.example.data.dictionary.OfflineDictionary
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testDictionaryDirectLookup() {
        val entry = OfflineDictionary.lookup("diligent")
        assertNotNull(entry)
        assertEquals("diligent", entry.word)
        assertTrue(entry.urduMeaning.contains("محنتی"))
        assertTrue(entry.romanUrdu.contains("Mehanti"))
        assertTrue(entry.synonyms.contains("hardworking"))
    }

    @Test
    fun testDictionaryStemming() {
        // Test plural
        val habitsEntry = OfflineDictionary.lookup("habits")
        assertEquals("habits", habitsEntry.word)
        assertTrue(habitsEntry.urduMeaning.contains("عادت"))

        // Test past tense
        val perseveredEntry = OfflineDictionary.lookup("persevered")
        assertTrue(perseveredEntry.urduMeaning.contains("ثابت قدم"))
    }

    @Test
    fun testContextDisambiguation() {
        // Test bank with river context
        val riverBank = OfflineDictionary.lookup("bank", "He walked along the cold river bank at sunset.")
        assertTrue("Expected river context, got: ${riverBank.urduMeaning}", riverBank.urduMeaning.contains("کنارہ"))

        // Test bank with money context
        val moneyBank = OfflineDictionary.lookup("bank", "She deposited cash in her savings account at the bank.")
        assertTrue("Expected financial context, got: ${moneyBank.urduMeaning}", moneyBank.urduMeaning.contains("مالیاتی"))
    }

    @Test
    fun testSentenceTranslation() {
        val translation = OfflineDictionary.translateSentenceLocally("Learning a foreign language is an extraordinary journey.")
        assertTrue(translation.isNotBlank())
    }
}
